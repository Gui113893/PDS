public interface Mediator {
    public void addColleague(Colleague colleague);
    public void notify(String message);
}
