interface Employee {
   public void showDetails(); 
}
